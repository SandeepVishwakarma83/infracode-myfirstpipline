variable "nsg_config" {
  
}
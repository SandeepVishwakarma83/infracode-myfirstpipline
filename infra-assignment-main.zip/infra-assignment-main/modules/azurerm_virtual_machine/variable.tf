variable "vm_config" {
  
}
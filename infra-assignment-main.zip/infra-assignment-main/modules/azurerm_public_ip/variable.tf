variable "ip_config" {
}
